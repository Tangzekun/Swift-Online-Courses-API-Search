//
//  ViewController.swift
//  APISearch
//
//  Created by TangZekun on 11/7/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import UIKit
import CoreSpotlight

class ViewController: UIViewController {
    
    let dogs = ["Fido", "Sarah", "Marcus", "Jane", "Mart"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        indexDogs()
        
        
    }

    func indexDogs()
    {
        for dog in self.dogs
        {
            let attributeSet = CSSearchableItemAttributeSet(itemContentType: "kUTTypeItem")
            attributeSet.title = dog
            attributeSet.contentDescription = "Learn more about the great dog named \(dog)"
            //let item = CSSearchableItem(uniqueIdentifier: dog, domainIdentifier: "Tang's APP", attributeSet: attributeSet)
            attributeSet.thumbnailData = UIImageJPEGRepresentation(UIImage(named: "panwar.jpg")!,1)
            attributeSet.keywords = ["dog", "tang", "neo"]
            //CSSearchableIndex.defaultSearchableIndex().indexSearchableItems([item], completionHandler: nil)
        }
    }
    


}

